const express = require('express');
const mysql = require('mysql');
const path = require('path');

const app = express();
const port = 8000;

// Configure MySQL connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'bhavya27465@',
  database: 'seller_appointment',
});

// Connect to MySQL
db.connect((err) => {
  if (err) {
    throw err;
  }
  console.log('Connected to MySQL database');
});

// Create MySQL table if it doesn't exist
const createTableQuery = `
  CREATE TABLE IF NOT EXISTS expenses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    expenseName VARCHAR(255) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    category VARCHAR(255) NOT NULL
  )
`;
db.query(createTableQuery, (err) => {
  if (err) {
    throw err;
  }
  console.log('MySQL table created');
});

// Serve static files
app.use(express.static(path.join(__dirname)));

// Handle GET request for root URL ("/")
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Handle GET request to retrieve products
app.get('/expenses', (req, res) => {
  const selectQuery = 'SELECT * FROM expenses';

  db.query(selectQuery, (err, results) => {
    if (err) {
      throw err;
    }

    res.json(results);
  });
});

// Handle POST request to add a product
app.post('/expenses', express.json(), (req, res) => {
  const { expenseName, price, category } = req.body;
  const insertQuery = 'INSERT INTO expenses (expenseName, price, category) VALUES (?, ?, ?)';
  const values = [expenseName, price, category];

  db.query(insertQuery, values, (err, result) => {
    if (err) {
      throw err;
    }

    const expense = {
      id: result.insertId,
      expenseName,
      price,
      category,
    };

    res.json(expense);
  });
});

// Handle DELETE request to delete a product
// Handle DELETE request to delete a product
app.delete('/expenses/:id', (req, res) => {
  const expenseId = req.params.id;
  const deleteQuery = 'DELETE FROM expenses WHERE id = ?';

  db.query(deleteQuery, [expenseId], (err) => {
    if (err) {
      throw err;
    }

    res.sendStatus(200);
  });
});

// Handle PUT request to update a product
app.put('/expenses/:id', express.json(), (req, res) => {
  const expenseId = req.params.id;
  const { expenseName, price, category } = req.body;
  const updateQuery = 'UPDATE expenses SET expenseName = ?, price = ?, category = ? WHERE id = ?';
  const values = [expenseName, price, category, expenseId];

  db.query(updateQuery, values, (err, result) => {
    if (err) {
      throw err;
    }

    res.json(result);
  });
});
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});