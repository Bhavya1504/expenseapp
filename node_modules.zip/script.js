document.addEventListener('DOMContentLoaded', () => {
    const addExpenseForm = document.getElementById('addExpense');
    const expenseNameInput = document.getElementById('expenseNameInput');
    const priceInput = document.getElementById('priceInput');
    const categorySelect = document.getElementById('categorySelect');
    const expenseList = document.getElementById('expenseList');
  
    let updatingExpenseId = null; // Variable to store the ID of the expense being updated
  
    addExpenseForm.addEventListener('submit', (e) => {
      e.preventDefault();
  
      const expenseName = expenseNameInput.value;
      const price = priceInput.value;
      const category = categorySelect.value;
  
      const expense = {
        expenseName,
        price,
        category,
      };
  
      if (updatingExpenseId) {
        // Update existing expense
        updateExpense(updatingExpenseId, expense);
      } else {
        // Add new expense
        saveExpense(expense);
      }
  
      // Clear the form inputs
      expenseNameInput.value = '';
      priceInput.value = '';
      categorySelect.value = '';
      updatingExpenseId = null; // Reset updatingExpenseId
    });
  
    function displayExpenses() {
      // Clear the expense list
      expenseList.innerHTML = '';
  
      // Retrieve expenses from MySQL database
      fetch('/expenses')
        .then((response) => response.json())
        .then((expenses) => {
          // Display expenses
          expenses.forEach((expense) => {
            const expenseItem = createExpenseItem(expense);
            expenseList.appendChild(expenseItem);
          });
        })
        .catch((error) => {
          console.error('Error:', error);
        });
    }
  
    function createExpenseItem(expense) {
      const expenseItem = document.createElement('div');
      expenseItem.id = `expense-${expense.id}`; // Set an ID for each expense item
      expenseItem.innerHTML = `
        <p><strong>Name:</strong> ${expense.expenseName}</p>
        <p><strong>Price:</strong> $${expense.price}</p>
        <p><strong>Category:</strong> ${expense.category}</p>
        <button data-action="update">Update</button>
        <button data-action="delete">Delete</button>
      `;
  
      const updateButton = expenseItem.querySelector(`#expense-${expense.id} button[data-action="update"]`);
      updateButton.addEventListener('click', () => showUpdateForm(expense));
  
      const deleteButton = expenseItem.querySelector(`#expense-${expense.id} button[data-action="delete"]`);
      deleteButton.addEventListener('click', () => deleteExpense(expense.id));
  
      return expenseItem;
    }
  
    function saveExpense(expense) {
      // Save to MySQL database
      fetch('/expenses', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(expense),
      })
        .then((response) => response.json())
        .then((data) => {
          // Refresh the expense list
          displayExpenses();
        })
        .catch((error) => {
          console.error('Error:', error);
        });
    }
  
    function showUpdateForm(expense) {
      // Set the form inputs to the expense details
      expenseNameInput.value = expense.expenseName;
      priceInput.value = expense.price;
      categorySelect.value = expense.category;
  
      updatingExpenseId = expense.id; // Set the updatingExpenseId to the ID of the expense being updated
    }
  
    function updateExpense(expenseId, expense) {
      // Update expense in MySQL database
      fetch(`/expenses/${expenseId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(expense),
      })
        .then((response) => response.json())
        .then((data) => {
          displayExpenses();
        })
        .catch((error) => {
          console.error('Error:', error);
        });
  
      // Clear the form inputs
      expenseNameInput.value = '';
      priceInput.value = '';
      categorySelect.value = '';
    }
  
    function deleteExpense(expenseId) {
      // Send a DELETE request to the server
      fetch(`/expenses/${expenseId}`, {
        method: 'DELETE',
      })
        .then((response) => {
          if (response.ok) {
            // Remove the deleted expense from the DOM
            const expenseElement = document.getElementById(`expense-${expenseId}`);
            expenseElement.remove();
          }
        })
        .catch((error) => {
          console.error('Error deleting expense:', error);
        });
    }
  
    // Initial display of expenses
    displayExpenses();
  });
  